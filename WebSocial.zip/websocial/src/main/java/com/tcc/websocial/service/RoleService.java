package com.tcc.websocial.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.tcc.websocial.model.Role;
import com.tcc.websocial.repository.filters.RoleFilter;

public interface RoleService extends GenericService<Role, Long> {

    Page<Role> listaComPaginacao(RoleFilter roleFilter, Pageable pageable);
    List<Role> buscarNome(String nome);

    Role findRole(String role);
	void saveUsuarioAuditoria(Role role, String operacao);
}