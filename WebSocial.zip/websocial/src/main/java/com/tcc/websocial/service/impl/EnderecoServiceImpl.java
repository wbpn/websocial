package com.tcc.websocial.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.tcc.websocial.model.Endereco;
import com.tcc.websocial.model.PArentesco;
import com.tcc.websocial.repository.EnderecoRepository;
import com.tcc.websocial.repository.Parentesco;
import com.tcc.websocial.service.EnderecoService;
import com.tcc.websocial.service.exceptions.EntidadeEmUsoException;
import com.tcc.websocial.service.exceptions.EnderecoNaoCadastradoException;

@Service
@Transactional
public class EnderecoServiceImpl implements EnderecoService {

    @Autowired
    private EnderecoRepository enderecoRepository;

    @Autowired
    private Parentesco parentesco;
    
    @Override
	@Transactional(readOnly = true)
    public List<Endereco> findAll() {
        return enderecoRepository.findAll();
    }

    @Override
    public Endereco save(Endereco endereco) {
        return enderecoRepository.save(endereco);
    }

    @Override
    public Endereco update(Endereco endereco) {
        return enderecoRepository.save(endereco);
    }

    @Override
	@Transactional(readOnly = true)
    public Endereco getOne(Long id) {
        return enderecoRepository.getOne(id);
    }

    @Override
    public Endereco findById(Long id) {
        return enderecoRepository.findById(id).orElseThrow(() -> new EnderecoNaoCadastradoException(id));
    }

    @Override
    public void deleteById(Long id) {
		try {
			enderecoRepository.deleteById(id);
		} catch(DataIntegrityViolationException e) {
			throw new EntidadeEmUsoException(String.format("O endereco de código %d não pode ser removido!", id));
		} catch (EmptyResultDataAccessException e){
			throw new EnderecoNaoCadastradoException(String.format("O endereco com o código %d não foi encontrado!", id));
		}
    }
    
    @Override
    public Long findPArentescoByIdEndereco(Long id) {
        return enderecoRepository.getOne(id).getPArentesco().getId();
    }

    @Override
    public Long findSerieByIdEndereco(Long id) {
        return enderecoRepository.getOne(id).getPArentesco().getSerie().getId();
    }

    @Override
    public void atualizarQtdEnderecos(Long id) {
        PArentesco temporada = parentesco.getOne(findPArentescoByIdEndereco(id));
        temporada.setQtdEnderecos(temporada.getEnderecos().size());
    }
}