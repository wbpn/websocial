package com.tcc.websocial.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.tcc.websocial.model.Parentesco;
import com.tcc.websocial.repository.filters.ParentescoFilter;

public interface ParentescoService extends GenericService<Parentesco, Long>{

	List<Parentesco> buscarNome(String nome);
    Page<Parentesco> listaComPaginacao(ParentescoFilter parentescoFilter, Pageable pageable);

    // void salvarParentesco(Parentesco parentesco);
    // Parentesco adicionarParentesco(Parentesco parentesco);
    // Parentesco removerParentesco(Parentesco parentesco, int index);
    // Parentesco buscarPorIdParentesco(Long id);
}