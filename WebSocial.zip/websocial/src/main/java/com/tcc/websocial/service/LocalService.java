package com.tcc.websocial.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.tcc.websocial.model.Local;
import com.tcc.websocial.repository.filters.LocalFilter;

public interface LocalService extends GenericService<Local, Long> {

    List<Local> buscarNome(String nome);
    Page<Local> listaComPaginacao(LocalFilter localFilter, Pageable pageable);
}