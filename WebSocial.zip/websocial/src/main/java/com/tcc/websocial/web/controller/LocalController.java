package com.tcc.websocial.web.controller;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperPrint;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.tcc.websocial.config.WebSocialConfig;
import com.tcc.websocial.model.Local;
import com.tcc.websocial.repository.filters.LocalFilter;
import com.tcc.websocial.repository.pagination.Pagina;
import com.tcc.websocial.service.LocalService;
import com.tcc.websocial.service.JasperReportsService;

@Controller
@RequestMapping(value = "/local")
public class LocalController {

    private static final String LOCAL = "local";
    private static final String SUCCESS = "success";
    private static final String LISTA = "redirect:/local/lista";

    @Autowired
    private LocalService localService;

    @Autowired
    private JasperReportsService jasperReportsService;
    
    @GetMapping("/lista")
    public ModelAndView lista(LocalFilter localFilter, HttpServletRequest httpServletRequest, @RequestParam(value = "page", required = false) Optional<Integer> page, @RequestParam(value = "size", required = false) Optional<Integer> size) {
        Pageable pageable = PageRequest.of(page.orElse(WebSocialConfig.INITIAL_PAGE), size.orElse(WebSocialConfig.INITIAL_PAGE_SIZE));
        Pagina<Local> pagina = new Pagina<>(localService.listaComPaginacao(localFilter, pageable), size.orElse(WebSocialConfig.INITIAL_PAGE_SIZE), httpServletRequest);
        ModelAndView modelAndView = new ModelAndView("/local/lista");
        modelAndView.addObject("pageSizes", WebSocialConfig.PAGE_SIZES);
        modelAndView.addObject("size", size.orElse(WebSocialConfig.INITIAL_PAGE_SIZE));
        modelAndView.addObject("pagina", pagina);
        return modelAndView;
    }

    @GetMapping("/cadastro")
    public ModelAndView cadastro(Local local) {
        ModelAndView modelAndView = new ModelAndView("/local/local");
        modelAndView.addObject(LOCAL, local);
        return modelAndView;
    }

    @GetMapping("/detalhes/{id}")
    public ModelAndView detalhes(@PathVariable("id") Long id) {
        ModelAndView modelAndView = new ModelAndView("/local/detalhes");
        Local local = localService.getOne(id);
        modelAndView.addObject(LOCAL, local);
        return modelAndView;
    }

    @GetMapping("/alterar/{id}")
    public ModelAndView buscar(@PathVariable("id") Long id) {
        ModelAndView modelAndView = new ModelAndView("/local/local");
        Local local = localService.getOne(id);
        modelAndView.addObject(LOCAL, local);
        return modelAndView;
    }

    @GetMapping("/remover/{id}")
    public ModelAndView removerId(@PathVariable("id") Long id) {
        ModelAndView modelAndView = new ModelAndView("/local/remover");
        Local local = localService.getOne(id);
        modelAndView.addObject(LOCAL, local);
        return modelAndView;
    }

    @PostMapping(value = "/adicionar")
    public ModelAndView adicionar(@Valid Local local, BindingResult result, RedirectAttributes attributes) {
        if (result.hasErrors()) {
            return cadastro(local);
        }
        localService.save(local);
        attributes.addFlashAttribute(SUCCESS, "Registro adicionado com sucesso.");
        return new ModelAndView(LISTA);
    }

    @PostMapping(value = "/alterar")
    public ModelAndView alterar(@Valid Local local, BindingResult result, RedirectAttributes attributes) {
        if (result.hasErrors()) {
            return cadastro(local);
        }
        localService.update(local);
        attributes.addFlashAttribute(SUCCESS, "Registro alterado com sucesso.");
        return new ModelAndView(LISTA);
    }

    @PostMapping(value = "/remover")
    public ModelAndView remover(Local local, BindingResult result, RedirectAttributes attributes) {
        localService.deleteById(local.getId());
        attributes.addFlashAttribute(SUCCESS, "Registro removido com sucesso.");
        return new ModelAndView(LISTA);
    }

    @PostMapping(value = { "/adicionar", "/alterar", "/remover" }, params = "action=cancelar")
    public String cancelar() {
        return LISTA;
    }
    
    @GetMapping("/download")
    public void imprimeRelatorioDownload(HttpServletResponse response) {
    	JasperPrint jasperPrint = null;
    	jasperPrint = jasperReportsService.imprimeRelatorioDownload("local");
    	response.setContentType("application/x-download");
    	response.setHeader("Content-Disposition", String.format("attachment; filename=\"local.pdf\""));
    	try {
			OutputStream out = response.getOutputStream();
			JasperExportManager.exportReportToPdfStream(jasperPrint, out);
		} catch (IOException | JRException e) {
			e.printStackTrace();
		}
    }
    
    @GetMapping("/pdf")
    public ResponseEntity<byte[]> imprimeRelatorioPdf() {
    	byte[] relatorio = jasperReportsService.imprimeRelatorioNoNavegador("local");
    	return ResponseEntity.ok().header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_PDF_VALUE).body(relatorio);
    }
}