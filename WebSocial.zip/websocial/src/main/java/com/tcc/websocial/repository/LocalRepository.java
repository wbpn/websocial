package com.tcc.websocial.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.tcc.websocial.model.Local;
import com.tcc.websocial.repository.query.LocalQuery;

@Repository
public interface LocalRepository extends JpaRepository<Local, Long>, LocalQuery {

    @Query("SELECT c FROM Local c WHERE c.nome like %:nome%")
    List<Local> buscarNome(@Param("nome") String nome);
}