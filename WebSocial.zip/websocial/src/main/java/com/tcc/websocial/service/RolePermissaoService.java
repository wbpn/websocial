package com.tcc.websocial.service;

import java.util.List;

import com.tcc.websocial.model.RolePermissao;
import com.tcc.websocial.model.RolePermissaoId;
import com.tcc.websocial.repository.filters.RolePermissaoFilter;

public interface RolePermissaoService extends GenericService<RolePermissao, RolePermissaoId> {

	List<RolePermissao> findRolePermissaoEscopoFilter(RolePermissaoFilter rolePermissaoFilter);
}