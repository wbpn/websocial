package com.tcc.websocial.service.exceptions;

import org.springframework.security.core.AuthenticationException;

public class PessoaNaoCadastradoException extends AuthenticationException {

    private static final long serialVersionUID = 0;

    public PessoaNaoCadastradoException(String msg) {
        super(msg);
    }

    public PessoaNaoCadastradoException(Long id) {
        this(String.format("Não existe este cadastro com o código %d", id));
    }
}