package com.tcc.websocial.repository.filters;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ContatoFilter {

    private String numerocontato;
}