package com.tcc.websocial.web.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.tcc.websocial.model.Endereco;
import com.tcc.websocial.service.EnderecoService;

@Controller
@RequestMapping(value = "/serie/{id}/parentesco/{id}/endereco")
public class EnderecoController {

    private static final String ENDERECO = "endereco";
    private static final String REDIRECT_SERIE = "redirect:/serie/";
    private static final String HTML_ENDERECO = "/endereco/endereco";

    @Autowired
    private EnderecoService enderecoService;
    
    @GetMapping("{id}")
    public ModelAndView detalhes(@PathVariable("id") Long id) {
        ModelAndView modelAndView = new ModelAndView("/endereco/detalhes");
        Endereco endereco = enderecoService.getOne(id);
        modelAndView.addObject(ENDERECO, endereco);
        return modelAndView;
    }

    @GetMapping("/{id}/alterar")
    public ModelAndView viewAlterar(@PathVariable("id") Long id) {
        ModelAndView modelAndView = new ModelAndView(HTML_ENDERECO);
        Endereco endereco = enderecoService.getOne(id);
        modelAndView.addObject(ENDERECO, endereco);
        return modelAndView;
    }

    @PostMapping("/{id}/alterar")
    public String alterar(@PathVariable("id") Long id, @Valid Endereco endereco, BindingResult result, RedirectAttributes attributes) {
        Long idSerie = enderecoService.findSerieByIdEndereco(id);
        Long idParentesco = enderecoService.findParentescoByIdEndereco(id);
        if (result.hasErrors()) {
            return REDIRECT_SERIE + idSerie + "/parentesco/" + idParentesco + "/endereco/" + id + "/alterar";
        }
        enderecoService.update(endereco);
        attributes.addFlashAttribute("success", "Registro alterado com sucesso.");
        return REDIRECT_SERIE + idSerie + "/parentesco/" + idParentesco + "/endereco/" + id;
    }

    @GetMapping("/{id}/remover")
    public ModelAndView viewRemover(@PathVariable("id") Long id) {
        ModelAndView modelAndView = new ModelAndView("/endereco/remover");
        Endereco endereco = enderecoService.getOne(id);
        modelAndView.addObject(ENDERECO, endereco);
        return modelAndView;
    }

    @PostMapping("/{id}/remover")
    public String remover(@PathVariable("id") Long id, RedirectAttributes attributes) {
        Long idSerie = enderecoService.findSerieByIdEndereco(id);
        Long idParentesco = enderecoService.findParentescoByIdEndereco(id);
        enderecoService.deleteById(id);
        enderecoService.atualizarQtdEnderecos(id);
        attributes.addFlashAttribute("success", "Registro removido com sucesso.");
        return REDIRECT_SERIE + idSerie + "/parentesco/" + idParentesco;
    }

    @PostMapping(value = { "", "/", "/{id}/alterar", "/{id}/remover" }, params = "cancelar")
	public String cancelar(@PathVariable("id") Long id) {
        Long idSerie = enderecoService.findSerieByIdEndereco(id);
        Long idParentesco = enderecoService.findParentescoByIdEndereco(id);
		return REDIRECT_SERIE + idSerie + "/parentesco/" + idParentesco + "/endereco/" + id;
    }
}