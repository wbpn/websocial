package com.tcc.websocial.repository.query;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.tcc.websocial.model.Parentesco;
import com.tcc.websocial.repository.filters.ParentescoFilter;

public interface ParentescoQuery {

	Page<Parentesco> listaComPaginacao(ParentescoFilter contatoFilter, Pageable pageable);
    
}