package com.tcc.websocial.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.tcc.websocial.model.Pessoa;
import com.tcc.websocial.repository.PessoaRepository;
import com.tcc.websocial.repository.filters.PessoaFilter;
import com.tcc.websocial.service.PessoaService;
import com.tcc.websocial.service.exceptions.PessoaNaoCadastradoException;
import com.tcc.websocial.service.exceptions.EntidadeEmUsoException;

@Service
@Transactional
public class PessoaServiceImpl implements PessoaService {

    @Autowired
    private PessoaRepository pessoaRepository;
    
    @Override
    @Transactional(readOnly = true)
    public List<Pessoa> findAll() {
        return pessoaRepository.findAll();
    }

    @Override
    public Pessoa save(Pessoa pessoa) {
        return pessoaRepository.save(pessoa);
    }

    @Override
    public Pessoa update(Pessoa pessoa) {
        return pessoaRepository.save(pessoa);
    }

    @Override
    @Transactional(readOnly = true)
    public Pessoa getOne(Long id) {
		return pessoaRepository.getOne(id);
    }

    @Override
    public Pessoa findById(Long id) {
		return pessoaRepository.findById(id).orElseThrow(()-> new PessoaNaoCadastradoException(id));
    }

    @Override
    public void deleteById(Long id) {
		try {
			pessoaRepository.deleteById(id);
		} catch(DataIntegrityViolationException e) {
			throw new EntidadeEmUsoException(String.format("O artista de código %d não pode ser removido!", id));
		} catch (EmptyResultDataAccessException e){
			throw new PessoaNaoCadastradoException(String.format("O artista com o código %d não foi encontrado!", id));
		}
    }

    @Override
    public List<Pessoa> buscarNome(String nome) {
        return pessoaRepository.buscarNome(nome);
    }

    @Override
    public Page<Pessoa> listaComPaginacao(PessoaFilter pessoaFilter, Pageable pageable) {
        return pessoaRepository.listaComPaginacao(pessoaFilter, pageable);
    }
}