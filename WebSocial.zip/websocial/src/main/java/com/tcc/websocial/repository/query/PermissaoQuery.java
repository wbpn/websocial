package com.tcc.websocial.repository.query;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.tcc.websocial.model.Permissao;
import com.tcc.websocial.repository.filters.PermissaoFilter;

public interface PermissaoQuery {

    Page<Permissao> listaComPaginacao(PermissaoFilter permissaoFilter, Pageable pageable);
}