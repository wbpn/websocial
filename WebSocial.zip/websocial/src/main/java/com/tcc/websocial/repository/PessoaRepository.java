package com.tcc.websocial.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.tcc.websocial.model.Pessoa;
import com.tcc.websocial.repository.query.PessoaQuery;

@Repository
public interface PessoaRepository extends JpaRepository<Pessoa, Long>, PessoaQuery {

    @Query("SELECT a FROM Pessoa a WHERE a.nome like %:nome%")
    List<Pessoa> buscarNome(@Param("nome") String nome);
}