package com.tcc.websocial.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.tcc.websocial.model.enumerate.TipoDocumento;
import com.tcc.websocial.model.enumerate.TipoDoenca;
import com.tcc.websocial.model.enumerate.TipoParentesco;
import com.tcc.websocial.model.enumerate.TipoSexo;
import com.tcc.websocial.model.enumerate.TipoTelefone;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString(onlyExplicitlyIncluded = true)
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity
@SequenceGenerator(name = "parentesco_sequence", sequenceName = "parentesco_sequence", initialValue = 1, allocationSize = 1)
public class Parentesco implements Serializable {

    private static final long serialVersionUID = 2386611204242179779L;

    @Id
    @EqualsAndHashCode.Include
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "parentesco_sequence")
    @Column(name = "parentesco_id")
    private Long id;

    @Size(min = 3, max = 40, message = "O nome deve ter entre 03 e 30 caracteres.")
	@NotBlank(message = "O nome deve ser informado.")
	@NotNull(message = "O nome deve ser informado.")
	@Column(length = 40, nullable = false)
    private String nome;

    @Size(min = 3, max = 150, message = "O sobrenome deve ter entre 03 e 140 caracteres.")
	@NotBlank(message = "O sobrenome deve ser informado.")
	@NotNull(message = "O sobrenome deve ser informado.")
	@Column(length = 40, nullable = false)
    private String sobrenome;    
    @OneToOne(mappedBy = "parentesco", fetch = FetchType.LAZY)
    
    @Size(min = 3, max = 150, message = "O apelido deve ter entre 03 e 140 caracteres.")
	@NotBlank(message = "O apelido deve ser informado.")
	@NotNull(message = "O apelido deve ser informado.")
	@Column(length = 40, nullable = false)
    private String apelido;    
    @OneToOne(mappedBy = "parentesco", fetch = FetchType.LAZY)
    
    @Size(min = 15, max = 150, message = "O e-mail deve ter entre 15 e 140 caracteres.")
	@NotBlank(message = "O e-mail deve ser informado.")
	@NotNull(message = "O e-mail deve ser informado.")
	@Column(length = 40, nullable = false)
    private String email;    
    @OneToOne(mappedBy = "parentesco", fetch = FetchType.LAZY)
    
    private TipoDoenca tipodoenca;
    private TipoTelefone tipotelefone;
    private TipoSexo tiposexo;
    private TipoDocumento tipodocumento;
    private TipoParentesco tipodeparentesco;
    private Contato contato;
    
}