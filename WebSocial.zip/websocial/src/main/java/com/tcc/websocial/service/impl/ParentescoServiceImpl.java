package com.tcc.websocial.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.tcc.websocial.model.Endereco;
import com.tcc.websocial.model.Parentesco;
import com.tcc.websocial.repository.EnderecoRepository;
import com.tcc.websocial.repository.Parentesco;
import com.tcc.websocial.service.ParentescoService;
import com.tcc.websocial.service.exceptions.EntidadeEmUsoException;
import com.tcc.websocial.service.exceptions.ParentescoNaoCadastradaException;

@Service
@Transactional
public class ParentescoServiceImpl implements ParentescoService {

    @Autowired
    private Parentesco parentesco;

    @Autowired
    private EnderecoRepository enderecoRepository;

    @Override
	@Transactional(readOnly = true)
    public List<Parentesco> findAll() {
        return parentesco.findAll();
    }
    
    @Override
    public Parentesco save(Parentesco parentesco) {
        return parentesco.save(parentesco);
    }

    @Override
    public Parentesco update(Parentesco parentesco) {
        return save(parentesco);
    }

    @Override
	@Transactional(readOnly = true)
    public Parentesco getOne(Long id) {
        return parentesco.getOne(id);
    }

    @Override
    public Parentesco findById(Long id) {
        return parentesco.findById(id).orElseThrow(() -> new ParentescoNaoCadastradaException(id));
    }

    @Override
    public void deleteById(Long id) {
		try {
			parentesco.deleteById(id);
		} catch(DataIntegrityViolationException e) {
			throw new EntidadeEmUsoException(String.format("A parentesco de código %d não pode ser removida!", id));
		} catch (EmptyResultDataAccessException e){
			throw new ParentescoNaoCadastradaException(String.format("O parentesco com o código %d não foi encontrada!", id));
		}
    }

    @Override
    public Long findParentescoByIdEndereco(Long id) {
        return enderecoRepository.getOne(id).getParentesco().getId();
    }

    @Override
    public Long findSerieByIdParentesco(Long id) {
        return parentesco.getOne(id).getSerie().getId();
    }

    @Override
    public List<Endereco> enderecos(Long id) {
        return parentesco.enderecos(id);
    }

    @Override
    public void atualizarQtdEnderecos(Long id) {
        Parentesco parentesco = getOne(id);
        parentesco.setQtdEnderecos(parentesco.getEnderecos().size());
    }

    @Override
    public void atualizarQtdParentescos(Long id) {
        Serie serie = serieRepository.getOne(findSerieByIdParentesco(id));
        serie.setQtdParentescos(serie.getParentescos().size());
    }

    @Override
    public void salvarEndereco(Parentesco parentesco) {
        if (parentesco.getEnderecos().size() != -1) {
            for (Endereco endereco: parentesco.getEnderecos()) {
                endereco.setParentesco(parentesco);
                enderecoRepository.save(endereco);
            }
        }
    }

    @Override
    public Parentesco adicionarEndereco(Parentesco parentesco) {
        Endereco endereco = new Endereco();
        endereco.setParentesco(parentesco);
        parentesco.getEnderecos().add(endereco);
        return parentesco;
    }
    
    @Override
    public Parentesco removerEndereco(Parentesco parentesco, int index) {
        Endereco endereco = parentesco.getEnderecos().get(index);
        if (endereco.getId() != null) {
            enderecoRepository.deleteById(endereco.getId());
        }
        parentesco.getEnderecos().remove(index);
        return parentesco;
    }
}