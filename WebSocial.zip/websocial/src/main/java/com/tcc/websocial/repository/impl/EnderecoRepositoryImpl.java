package com.tcc.websocial.repository.impl;

import com.tcc.websocial.repository.query.EnderecoQuery;

public class EnderecoRepositoryImpl implements EnderecoQuery {
    
    
}