package com.tcc.websocial.repository.query;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.tcc.websocial.model.Local;
import com.tcc.websocial.repository.filters.LocalFilter;

public interface LocalQuery {

    Page<Local> listaComPaginacao(LocalFilter localFilter, Pageable pageable);
}