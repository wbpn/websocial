package com.tcc.websocial.web.controller;

import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.tcc.websocial.config.WebSocialConfig;
import com.tcc.websocial.model.Contato;
import com.tcc.websocial.repository.filters.ContatoFilter;
import com.tcc.websocial.repository.pagination.Pagina;
import com.tcc.websocial.service.ContatoService;

@Controller
@RequestMapping(value = "/contato")
public class ContatoController {

    private static final String CONTATO = "contato";
    private static final String SUCCESS = "success";
    private static final String LISTA = "redirect:/contato/lista";

    @Autowired
    private ContatoService contatoService;

    @GetMapping("/lista")
    public ModelAndView lista(ContatoFilter contatoFilter, HttpServletRequest httpServletRequest, @RequestParam(value = "page", required = false) Optional<Integer> page, @RequestParam(value = "size", required = false) Optional<Integer> size) {
        Pageable pageable = PageRequest.of(page.orElse(WebSocialConfig.INITIAL_PAGE), size.orElse(WebSocialConfig.INITIAL_PAGE_SIZE));
        Pagina<Contato> pagina = new Pagina<>(contatoService.listaComPaginacao(contatoFilter, pageable), size.orElse(WebSocialConfig.INITIAL_PAGE_SIZE), httpServletRequest);
        ModelAndView modelAndView = new ModelAndView("/contato/lista");
        modelAndView.addObject("pageSizes", WebSocialConfig.PAGE_SIZES);
        modelAndView.addObject("size", size.orElse(WebSocialConfig.INITIAL_PAGE_SIZE));
        modelAndView.addObject("pagina", pagina);
        return modelAndView;
    }

    @GetMapping("/cadastro")
    public ModelAndView cadastro(Contato contato) {
        ModelAndView modelAndView = new ModelAndView("/contato/contato");
        modelAndView.addObject(CONTATO, contato);
        return modelAndView;
    }

    @GetMapping("/detalhes/{id}")
    public ModelAndView detalhes(@PathVariable("id") Long id) {
        ModelAndView modelAndView = new ModelAndView("/contato/detalhes");
        Contato contato = contatoService.getOne(id);
        modelAndView.addObject(CONTATO, contato);
        return modelAndView;
    }

    @GetMapping("/alterar/{id}")
    public ModelAndView buscar(@PathVariable("id") Long id) {
        ModelAndView modelAndView = new ModelAndView("/contato/contato");
        Contato contato = contatoService.getOne(id);
        modelAndView.addObject(CONTATO, contato);
        return modelAndView;
    }

    @GetMapping("/remover/{id}")
    public ModelAndView removerId(@PathVariable("id") Long id) {
        ModelAndView modelAndView = new ModelAndView("/contato/remover");
        Contato contato = contatoService.getOne(id);
        modelAndView.addObject(CONTATO, contato);
        return modelAndView;
    }

    @PostMapping(value = "/adicionar")
    public ModelAndView adicionar(@Valid Contato contato, BindingResult result, RedirectAttributes attributes) {
        if (result.hasErrors()) {
            return cadastro(contato);
        }
        contatoService.save(contato);
        attributes.addFlashAttribute(SUCCESS, "Registro adicionado com sucesso.");
        return new ModelAndView(LISTA);
    }

    @PostMapping(value = "/alterar")
    public ModelAndView alterar(@Valid Contato contato, BindingResult result, RedirectAttributes attributes) {
        if (result.hasErrors()) {
            return cadastro(contato);
        }
        contatoService.update(contato);
        attributes.addFlashAttribute(SUCCESS, "Registro alterado com sucesso.");
        return new ModelAndView(LISTA);
    }

    @PostMapping(value = "/remover")
    public ModelAndView remover(Contato contato, BindingResult result, RedirectAttributes attributes) {
        contatoService.deleteById(contato.getId());
        attributes.addFlashAttribute(SUCCESS, "Registro removido com sucesso.");
        return new ModelAndView(LISTA);
    }

    @PostMapping(value = { "/adicionar", "/alterar", "/remover" }, params = "action=cancelar")
	public String cancelar() {
		return LISTA;
	}
}