package com.tcc.websocial.service.exceptions;

import org.springframework.security.core.AuthenticationException;

public class ContatoNaoCadastradoException extends AuthenticationException {

    private static final long serialVersionUID = 0;

    public ContatoNaoCadastradoException(String msg) {
        super(msg);
    }

    public ContatoNaoCadastradoException(Long id) {
        this(String.format("Não existe um cadastro com o código %d", id));
    }
}