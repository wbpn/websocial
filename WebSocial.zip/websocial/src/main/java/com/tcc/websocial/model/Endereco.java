package com.tcc.websocial.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;


import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString(onlyExplicitlyIncluded = true)
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity
@SequenceGenerator(name = "endereco_sequence", sequenceName = "endereco_sequence", initialValue = 1, allocationSize = 1)
public class Endereco implements Serializable {

    private static final long serialVersionUID = 0;

    @Id
    @EqualsAndHashCode.Include
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "endereco_sequence")
    @Column(name = "endereco_id")
    private Long id;

    @Size(min = 3, max = 140, message = "O nome da rua deve ter entre 03 e 140 caracteres.")
	@NotBlank(message = "O nome da rua deve ser informado.")
	@NotNull(message = "O nome da rua deve ser informado.")
	@Column(length = 40, nullable = false)
    private String rua;

    @Size(min = 1, max = 5, message = "O numero deve ter entre 01 e 05 caracteres.")
	@NotBlank(message = "O numero deve ser informado.")
	@NotNull(message = "O numero deve ser informado.")
	@Column(length = 6, nullable = false)
    private String numero;    
    
    @Size(min = 3, max = 150, message = "O bairro deve ter entre 03 e 140 caracteres.")
	@NotBlank(message = "O bairro deve ser informado.")
	@NotNull(message = "O bairro deve ser informado.")
	@Column(length = 40, nullable = false)
    private String bairro;
    
    @Size(min = 8, max = 8, message = "O cep deve ter 08 caracteres.")
	@NotBlank(message = "O cep deve ser informado.")
	@NotNull(message = "O cep deve ser informado.")
	@Column(length = 12, nullable = false)
    private String cep;
    
    
}