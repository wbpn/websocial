package com.tcc.websocial.service.exceptions;

public class NegocioException extends RuntimeException {

    private static final long serialVersionUID = 0;

    public NegocioException(String message) {
        super(message);
    }
}