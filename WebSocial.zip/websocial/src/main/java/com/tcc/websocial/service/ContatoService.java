package com.tcc.websocial.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.tcc.websocial.model.Contato;
import com.tcc.websocial.repository.filters.ContatoFilter;

public interface ContatoService extends GenericService<Contato, Long>{

    List<Contato> buscarNumeroContato(String numerocontato);
    Page<Contato> listaComPaginacao(ContatoFilter contatoFilter, Pageable pageable);
}