package com.tcc.websocial.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.tcc.websocial.model.Local;
import com.tcc.websocial.repository.LocalRepository;
import com.tcc.websocial.repository.filters.LocalFilter;
import com.tcc.websocial.service.LocalService;
import com.tcc.websocial.service.exceptions.LocalNaoCadastradaException;
import com.tcc.websocial.service.exceptions.EntidadeEmUsoException;

@Service
@Transactional
public class LocalServiceImpl implements LocalService {

    @Autowired
    private LocalRepository localRepository;

    @Override
    @Transactional(readOnly = true)
    public List<Local> findAll() {
        return localRepository.findAll();
    }

    @Override
    public Local save(Local local) {
        return localRepository.save(local);
    }

    @Override
    public Local update(Local local) {
        return localRepository.save(local);
    }

    @Override
    @Transactional(readOnly = true)
    public Local getOne(Long id) {
        return localRepository.getOne(id);
    }

    @Override
    public Local findById(Long id) {
		return localRepository.findById(id).orElseThrow(()-> new LocalNaoCadastradaException(id));
    }

    @Override
    public void deleteById(Long id) {
		try {
			localRepository.deleteById(id);
		} catch(DataIntegrityViolationException e) {
			throw new EntidadeEmUsoException(String.format("O local de código %d não pode ser removido!", id));
		} catch (EmptyResultDataAccessException e){
			throw new LocalNaoCadastradaException(String.format("A local com o código %d não foi encontrada!", id));
		}
    }
    
    @Override
    public List<Local> buscarNome(String nome) {
		return localRepository.buscarNome(nome);
    }

    @Override
    public Page<Local> listaComPaginacao(LocalFilter localFilter, Pageable pageable) {
        return localRepository.listaComPaginacao(localFilter, pageable);
    }
}