package com.tcc.websocial.service;

import java.util.List;

import org.springframework.security.core.Authentication;

import com.tcc.websocial.model.Permission;

public interface PermissionService {

    boolean hasPermission(Authentication usuarioLogado, Object permissao, Object escopo);
    List<Permission> findRolePermissaoByUsuarioId(Long id);
}