package com.tcc.websocial.web.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.tcc.websocial.model.Escopo;
import com.tcc.websocial.model.Permissao;
import com.tcc.websocial.model.Role;
import com.tcc.websocial.model.RolePermissao;
import com.tcc.websocial.model.RolePermissaoId;
import com.tcc.websocial.repository.filters.RolePermissaoFilter;
import com.tcc.websocial.service.EscopoService;
import com.tcc.websocial.service.PermissaoService;
import com.tcc.websocial.service.RolePermissaoService;
import com.tcc.websocial.service.RoleService;

@Controller
@RequestMapping(value = "/direito")
public class RolePermissaoController {

    @Autowired
    private RoleService roleService;

    @Autowired
    private PermissaoService permissaoService;
    
    @Autowired
    private EscopoService escopoService;

    @Autowired
    private RolePermissaoService rolePermissaoService;

    @GetMapping("/lista")
    public ModelAndView lista(RolePermissaoFilter rolePermissaoFilter) {
        ModelAndView modelAndView = new ModelAndView("/direito/lista");
        List<RolePermissao> lista = rolePermissaoService.findRolePermissaoEscopoFilter(rolePermissaoFilter);
        modelAndView.addObject("lista", lista);
        return modelAndView;
    }

    @GetMapping("/cadastro")
    public ModelAndView cadastro(RolePermissao rolePermissao) {
        ModelAndView modelAndView = new ModelAndView("/direito/direito");
        modelAndView.addObject("rolePermissao", rolePermissao);
        return modelAndView;
    }

    @PostMapping("/adicionar")
    public ModelAndView adicionar(@Valid RolePermissao rolePermissao, RedirectAttributes attributes) {
        RolePermissaoId id = new RolePermissaoId();
        id.setRole(rolePermissao.getRole().getId());
        id.setPermissao(rolePermissao.getPermissao().getId());
        id.setEscopo(rolePermissao.getEscopo().getId());
        rolePermissao.setId(id);
        rolePermissaoService.save(rolePermissao);
        attributes.addFlashAttribute("success", "Registro adicionado com sucesso.");
        return new ModelAndView("redirect:/direito/lista");
    }

    @GetMapping("/remover/{roleId}/{permissaoId}/{escopoId}")
    public ModelAndView removerId(@PathVariable("roleId") Long roleId, @PathVariable("permissaoId") Long permissaoId, @PathVariable("escopoId") Long escopoId) {
        RolePermissaoId id = new RolePermissaoId();
        id.setRole(roleId);
        id.setPermissao(permissaoId);
        id.setEscopo(escopoId);
        RolePermissao rolePermissao = rolePermissaoService.getOne(id);
        ModelAndView modelAndView = new ModelAndView("/direito/remover");
        modelAndView.addObject("rolePermissao", rolePermissao);
        return modelAndView;
    }
    
    @PostMapping(value = "/remover")
    public ModelAndView remover(RolePermissao rolePermissao, BindingResult result, RedirectAttributes attributes) {
        rolePermissaoService.deleteById(rolePermissao.getId());
        attributes.addFlashAttribute("success", "Registro removido com sucesso.");
        return new ModelAndView("/direito/lista");
    }

    @ModelAttribute("roles")
    public List<Role> getRoles() {
        return roleService.findAll();
    }

    @ModelAttribute("permissoes")
    public List<Permissao> getPermissoes() {
        return permissaoService.findAll();
    }

    @ModelAttribute("escopos")
    public List<Escopo> getEscopos() {
        return escopoService.findAll();
    }

    @PostMapping(value = { "/adicionar", "/alterar", "/remover" }, params = "action=cancelar")
	public String cancelar() {
		return "redirect:/direito/lista";
    }
}