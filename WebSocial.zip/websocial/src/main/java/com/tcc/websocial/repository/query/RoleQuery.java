package com.tcc.websocial.repository.query;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.tcc.websocial.model.Role;
import com.tcc.websocial.repository.filters.RoleFilter;

public interface RoleQuery {

    Page<Role> listaComPaginacao(RoleFilter roleFilter, Pageable pageable);
}