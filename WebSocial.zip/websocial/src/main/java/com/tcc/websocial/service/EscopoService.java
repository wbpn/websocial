package com.tcc.websocial.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.tcc.websocial.model.Escopo;
import com.tcc.websocial.repository.filters.EscopoFilter;

public interface EscopoService extends GenericService<Escopo, Long> {

    List<Escopo> buscarNome(String nome);
    Page<Escopo> listaComPaginacao(EscopoFilter escopoFilter, Pageable pageable);
}