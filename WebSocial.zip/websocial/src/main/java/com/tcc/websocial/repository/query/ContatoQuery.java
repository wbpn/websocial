package com.tcc.websocial.repository.query;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.tcc.websocial.model.Contato;
import com.tcc.websocial.repository.filters.ContatoFilter;

public interface ContatoQuery {

    Page<Contato> listaComPaginacao(ContatoFilter contatoFilter, Pageable pageable);
}