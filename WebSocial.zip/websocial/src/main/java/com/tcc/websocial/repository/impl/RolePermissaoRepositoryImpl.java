package com.tcc.websocial.repository.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Root;

import org.springframework.util.StringUtils;

import com.tcc.websocial.model.Escopo;
import com.tcc.websocial.model.Permissao;
import com.tcc.websocial.model.Role;
import com.tcc.websocial.model.RolePermissao;
import com.tcc.websocial.repository.filters.RolePermissaoFilter;
import com.tcc.websocial.repository.query.RolePermissaoQuary;

public class RolePermissaoRepositoryImpl implements RolePermissaoQuary {

    @PersistenceContext
    private EntityManager entityManager;

	@Override
	public List<RolePermissao> findRolePermissaoEscopoFilter(RolePermissaoFilter rolePermissaoFilter) {
        TypedQuery<RolePermissao> query = null;
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<RolePermissao> criteriaQuery = criteriaBuilder.createQuery(RolePermissao.class);
        Root<RolePermissao> root = criteriaQuery.from(RolePermissao.class);
        
        if (!StringUtils.isEmpty(rolePermissaoFilter.getRole())) {
            Join<RolePermissao, Role> role = root.join("role");
            criteriaQuery.where(criteriaBuilder.like(criteriaBuilder.lower(role.get("nome")), "%" + rolePermissaoFilter.getRole() + "%"));
        } else {
            criteriaQuery.select(root);
        }
        
        if (!StringUtils.isEmpty(rolePermissaoFilter.getPermissao())) {
            Join<RolePermissao, Permissao> permissao = root.join("permissao");
            criteriaQuery.where(criteriaBuilder.like(criteriaBuilder.lower(permissao.get("nome")), "%" + rolePermissaoFilter.getPermissao() + "%"));
        } else {
            criteriaQuery.select(root);
        }
        
        if (!StringUtils.isEmpty(rolePermissaoFilter.getEscopo())) {
            Join<RolePermissao, Escopo> escopo = root.join("escopo");
            criteriaQuery.where(criteriaBuilder.like(criteriaBuilder.lower(escopo.get("nome")), "%" + rolePermissaoFilter.getEscopo() + "%"));
        } else {
            criteriaQuery.select(root);
        }

        query = entityManager.createQuery(criteriaQuery);
		return query.getResultList();
	}
}