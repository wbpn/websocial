package com.tcc.websocial.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.tcc.websocial.model.Role;
import com.tcc.websocial.repository.query.RoleQuery;

@Repository
public interface RoleRepository extends JpaRepository<Role, Long>, RoleQuery {

    @Query("SELECT r FROM Role r WHERE r.nome like %:nome%")
    List<Role> buscarNome(@Param("nome") String nome);

    @Query("SELECT r FROM Role r LEFT JOIN r.usuarios ")
	List<Role> findAllRoles();
}