package com.tcc.websocial.web.exception;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.tcc.websocial.security.UsuarioSistema;

@ControllerAdvice
public class ResourcesExceptionHandler {
    
    @ModelAttribute("usuarioLogado")
    public UsuarioSistema getUsuarioLogado(@AuthenticationPrincipal UsuarioSistema usuarioLogado) {
        return (usuarioLogado == null) ? null : usuarioLogado;
    }
}