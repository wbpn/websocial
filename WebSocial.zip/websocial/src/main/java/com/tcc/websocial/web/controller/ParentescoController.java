package com.tcc.websocial.web.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.tcc.websocial.model.Endereco;
import com.tcc.websocial.model.Pessoa;
import com.tcc.websocial.model.Parentesco;
import com.tcc.websocial.service.ParentescoService;

@Controller
@RequestMapping(value = "/pessoa/{id}/parentesco")
public class ParentescoController {

    private static final String PARENTESCO = "parentesco";
    private static final String SUCCESS = "success";
    private static final String REDIRECT_SERIE = "redirect:/pessoa/";
    private static final String HTML_PARENTESCO = "/parentesco/parentesco";

    @Autowired
    private ParentescoService parentescoService;

    @GetMapping("{id}")
    public ModelAndView detalhar(@PathVariable("id") Long id) {
        Parentesco parentesco = parentescoService.getOne(id);
        ModelAndView modelAndView = new ModelAndView("/parentesco/detalhes");
        modelAndView.addObject(PARENTESCO, parentesco);
        modelAndView.addObject("enderecos", parentescoService.enderecos(id));
        return modelAndView;
    }

    @GetMapping("/{id}/alterar")
    public ModelAndView viewAlterar(@PathVariable("id") Long id) {
        Parentesco parentesco = parentescoService.getOne(id);
        ModelAndView modelAndView = new ModelAndView(HTML_PARENTESCO);
        Episodio endereco = new Episodio();
        endereco.setParentesco(parentesco);
        parentesco.getEpisodios().add(endereco);
        modelAndView.addObject(PARENTESCO, parentesco);
        return modelAndView;
    }
    
    @PostMapping("/{id}/alterar")
    public String alterar(@PathVariable("id") Long id, @Valid Parentesco parentesco, BindingResult result, RedirectAttributes attributes) {
        Long cod = parentescoService.findPessoaByIdParentesco(id);
        if (result.hasErrors()) {
            attributes.addFlashAttribute("message", "Verifique os campos!");
            return REDIRECT_SERIE + cod + "/parentesco/" + parentesco.getId() + "/alterar";
        }
        parentescoService.update(parentesco);
        parentescoService.salvarEpisodio(parentesco);
        parentescoService.atualizarQtdEpisodios(id);
        attributes.addFlashAttribute(SUCCESS, "Registro alterado com sucesso.");
        return REDIRECT_SERIE + cod + "/parentesco/" + parentesco.getId();
    }

    @GetMapping(value = "/{id}/alterar", params = "addrow")
    public ModelAndView adicionarEpisodio(@PathVariable("id") Long id, Parentesco parentesco) {
        parentesco = parentescoService.adicionarEpisodio(parentesco);
        ModelAndView modelAndView = new ModelAndView(HTML_PARENTESCO);
        modelAndView.addObject(PARENTESCO, parentesco);
        return modelAndView;
    }

    @GetMapping(value = "/{id}/alterar", params = "removerow")
    public ModelAndView removerEpisodio(@PathVariable("id") Long id, Parentesco parentesco, HttpServletRequest request) {
        int index = Integer.parseInt(request.getParameter("removerow"));
        parentesco = parentescoService.removerEpisodio(parentesco, index);
        ModelAndView modelAndView = new ModelAndView(HTML_PARENTESCO);
        parentescoService.atualizarQtdEpisodios(id);
        modelAndView.addObject(PARENTESCO, parentesco);
        return modelAndView;
    }

    @GetMapping("/{id}/remover")
    public ModelAndView viewRemover(@PathVariable("id") Long id) {
        Parentesco parentesco = parentescoService.getOne(id);
        ModelAndView modelAndView = new ModelAndView("/parentesco/remover");
        modelAndView.addObject(PARENTESCO, parentesco);
        modelAndView.addObject("enderecos", parentescoService.enderecos(id));
        return modelAndView;
    }

    @PostMapping("/{id}/remover")
    public String remover(@PathVariable("id") Long id, RedirectAttributes attributes) {
        Long cod = parentescoService.findPessoaByIdParentesco(id);
        parentescoService.deleteById(id);
        parentescoService.atualizarQtdParentescos(cod);
        attributes.addFlashAttribute(SUCCESS, "Registro removido com sucesso.");
        return REDIRECT_SERIE + cod;
    }

    @PostMapping(value = { "", "/", "/{id}/alterar", "/{id}/remover" }, params = "cancelar")
	public String cancelar(@PathVariable("id") Long id) {
        Long idPessoa = parentescoService.findPessoaByIdParentesco(id);
		return REDIRECT_SERIE + idPessoa + "/parentesco/" + id;
    }
}