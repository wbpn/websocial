package com.tcc.websocial.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.tcc.websocial.model.Endereco;
import com.tcc.websocial.repository.query.EnderecoQuery;

@Repository
public interface EnderecoRepository extends JpaRepository<Endereco, Long>, EnderecoQuery {

    
}