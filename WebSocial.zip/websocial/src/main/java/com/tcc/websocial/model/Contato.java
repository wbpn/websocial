package com.tcc.websocial.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.tcc.websocial.model.enumerate.TipoTelefone;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString(onlyExplicitlyIncluded = true)
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity
@SequenceGenerator(name = "contato_sequence", sequenceName = "contato_sequence", initialValue = 1, allocationSize = 1)
public class Contato implements Serializable {

    private static final long serialVersionUID = 0;

    @Id
    @EqualsAndHashCode.Include
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "pessoa_sequence")
    @Column(name = "contato_id")
    private Long id;

    @Size(min = 10, max = 11, message = "O numero deve ser informado com DDD + Numero.")
	@NotBlank(message = "O numero deve ser informado.")
	@NotNull(message = "O numero deve ser informado.")
	@Column(length = 15, nullable = false)
    private String numerocontato;

    @ManyToMany(mappedBy="contatos")
    private List<TipoTelefone> tipotelefones = new ArrayList<>();
    
    private TipoTelefone tipotelefone;
    
}