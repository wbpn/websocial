package com.tcc.websocial.repository.query;

import java.util.List;

import com.tcc.websocial.model.RolePermissao;
import com.tcc.websocial.repository.filters.RolePermissaoFilter;

public interface RolePermissaoQuary {

	List<RolePermissao> findRolePermissaoEscopoFilter(RolePermissaoFilter rolePermissaoFilter); 
}