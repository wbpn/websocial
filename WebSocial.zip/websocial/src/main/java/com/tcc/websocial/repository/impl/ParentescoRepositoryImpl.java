package com.tcc.websocial.repository.impl;

import com.tcc.websocial.repository.query.ParentescoQuery;

public class ParentescoRepositoryImpl implements ParentescoQuery {

}