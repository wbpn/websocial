package com.tcc.websocial.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.tcc.websocial.model.Pessoa;
import com.tcc.websocial.repository.filters.PessoaFilter;

public interface PessoaService extends GenericService<Pessoa, Long> {

    List<Pessoa> buscarNome(String nome);
    Page<Pessoa> listaComPaginacao(PessoaFilter pessoaFilter, Pageable pageable);

    // void salvarCategoria(Pessoa pessoa);
    // Pessoa adicionarCategoria(Pessoa pessoa);
    // Pessoa removerCategoria(Pessoa pessoa, int index);
    // Pessoa buscarPorIdParentesco(Long id);
}