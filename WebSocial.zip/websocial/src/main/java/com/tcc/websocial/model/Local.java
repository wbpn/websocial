package com.tcc.websocial.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString(onlyExplicitlyIncluded = true)
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity
@SequenceGenerator(name = "local_sequence", sequenceName = "local_sequence", initialValue = 1, allocationSize = 1)
public class Local implements Serializable {

    private static final long serialVersionUID = 2386611204242179779L;

    @Id
    @EqualsAndHashCode.Include
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "local_sequence")
    @Column(name = "local_id")
    private Long id;

    @Size(min = 3, max = 140, message = "O pais deve ter entre 03 e 130 caracteres.")
	@NotBlank(message = "O pais deve ser informado.")
	@NotNull(message = "O pais deve ser informado.")
	@Column(length = 40, nullable = false)
    private String pais;

    @Size(min = 3, max = 150, message = "O estado deve ter entre 03 e 140 caracteres.")
	@NotBlank(message = "O estado deve ser informado.")
	@NotNull(message = "O estado deve ser informado.")
	@Column(length = 40, nullable = false)
    private String estado;
    
    @Size(min = 2, max = 2, message = "O UF deve ter 02 caracteres.")
	@NotBlank(message = "O UF deve ser informado.")
	@NotNull(message = "O UF deve ser informado.")
	@Column(length = 4, nullable = false)
    private String uf;
    
    @Size(min = 5, max = 150, message = "A cidade deve ter entre 5 e 140 caracteres.")
	@NotBlank(message = "A cidade deve ser informada.")
	@NotNull(message = "A cidade deve ser informada.")
	@Column(length = 150, nullable = false)
    private String cidade;
    
    private Pessoa pessoa;
}