package com.tcc.websocial.config;

import org.springframework.security.core.context.SecurityContextHolder;

import com.tcc.websocial.model.Usuario;
import com.tcc.websocial.security.UsuarioSistema;

public class WebSocialConfig {

	private WebSocialConfig() {
		throw new IllegalStateException("Configuração de Televisivo");
	}

	public static final int INITIAL_PAGE = 0;
	public static final int INITIAL_PAGE_SIZE = 10;
	public static final int[] PAGE_SIZES = { 5, 10, 15, 20 };
	public static final String NAO_DELETADO = "registro_deletado = false";
	public static final String INCLUSAO = "INSERT";
	public static final String ALTERACAO = "UPDATE";
	public static final String EXCLUSAO = "DELETE";
	
	public static Usuario pegarUsuario() {
		UsuarioSistema usuarioSistema = (UsuarioSistema) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		return usuarioSistema.getUsuario();
	}
}