package com.tcc.websocial.service.exceptions;

import org.springframework.security.core.AuthenticationException;

public class EnderecoNaoCadastradoException extends AuthenticationException {

    private static final long serialVersionUID = 0;

    public EnderecoNaoCadastradoException(String msg) {
        super(msg);
    }

    public EnderecoNaoCadastradoException(Long id) {
        this(String.format("Não existe um cadastro com o código %d", id));
    }
}