package com.tcc.websocial.service.exceptions;

import org.springframework.security.core.AuthenticationException;

public class ParentescoNaoCadastradaException extends AuthenticationException {

    private static final long serialVersionUID = 0;

    public ParentescoNaoCadastradaException(String msg) {
        super(msg);
    }

    public ParentescoNaoCadastradaException(Long id) {
        this(String.format("Não existe um cadastro de parentesco com o código %d", id));
    }
}