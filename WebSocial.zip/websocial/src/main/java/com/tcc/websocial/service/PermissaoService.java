package com.tcc.websocial.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.tcc.websocial.model.Permissao;
import com.tcc.websocial.repository.filters.PermissaoFilter;

public interface PermissaoService extends GenericService<Permissao, Long> {

    List<Permissao> buscarNome(String nome);
    Page<Permissao> listaComPaginacao(PermissaoFilter permissaoFilter, Pageable pageable);
}