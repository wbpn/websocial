package com.tcc.websocial.model.enumerate;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum TipoDocumento {

	RG("RG"),
	CPF("CPF"),
	CartaoCidadao("Cartao Cidadão"),
	DNI("DNI");
	
	private String descricao;
}
