package com.tcc.websocial.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.tcc.websocial.model.Endereco;
import com.tcc.websocial.repository.filters.EnderecoFilter;

public interface EnderecoService extends GenericService<Endereco, Long>{

	 List<Endereco> buscarNome(String nome);
	 Page<Endereco> listaComPaginacao(EnderecoFilter enderecoFilter, Pageable pageable);

	    // void salvarCategoria(Endereco endereco);
	    // Endereco adicionarCategoria(Endereco endereco);
	    // Endereco removerCategoria(Endereco endereco, int index);
	    // Endereco buscarPorIdContato(Long id);
}