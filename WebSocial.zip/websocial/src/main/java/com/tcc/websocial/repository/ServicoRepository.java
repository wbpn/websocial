package com.tcc.websocial.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.tcc.websocial.model.Servico;
import com.tcc.websocial.repository.query.ServicoQuery;

@Repository
public interface ServicoRepository extends JpaRepository<Servico, Long>, ServicoQuery {

    @Query("SELECT s FROM Servico s WHERE s.nome like %:nome%")
    List<Servico> buscarNome(@Param("nome") String nome);
}