package com.tcc.websocial.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.tcc.websocial.model.Contato;
import com.tcc.websocial.repository.ContatoRepository;
import com.tcc.websocial.repository.filters.ContatoFilter;
import com.tcc.websocial.service.ContatoService;
import com.tcc.websocial.service.exceptions.ContatoNaoCadastradoException;
import com.tcc.websocial.service.exceptions.EntidadeEmUsoException;

@Service
@Transactional
public class ContatoServiceImpl implements ContatoService {

    @Autowired
    private ContatoRepository contatoRepository;
    
    @Override
	@Transactional(readOnly = true)
    public List<Contato> findAll() {
        return contatoRepository.findAll();
    }

    @Override
    public Contato save(Contato contato) {
        return contatoRepository.save(contato);
    }

    @Override
    public Contato update(Contato contato) {
        return contatoRepository.save(contato);
    }

    @Override
	@Transactional(readOnly = true)
    public Contato getOne(Long id) {
        return contatoRepository.getOne(id);
    }

    @Override
    public Contato findById(Long id) {
		return contatoRepository.findById(id).orElseThrow(()-> new ContatoNaoCadastradoException(id));
    }

    @Override
    public void deleteById(Long id) {
		try {
			contatoRepository.deleteById(id);
		} catch(DataIntegrityViolationException e) {
			throw new EntidadeEmUsoException(String.format("O contato de código %d não pode ser removido!", id));
		} catch (EmptyResultDataAccessException e){
			throw new ContatoNaoCadastradoException(String.format("O contato com o código %d não foi encontrado!", id));
		}
    }
    
	@Override
	public List<Contato> buscarNumeroContato(String numerocontato) {
		return contatoRepository.buscarNumeroContato(numerocontato);
	}

    @Override
    public Page<Contato> listaComPaginacao(ContatoFilter contatoFilter, Pageable pageable) {
        return contatoRepository.listaComPaginacao(contatoFilter, pageable);
    }
}