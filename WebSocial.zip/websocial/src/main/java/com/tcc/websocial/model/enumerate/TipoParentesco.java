package com.tcc.websocial.model.enumerate;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum TipoParentesco {

	Pai("Pai"),
	Mae("Mãe"),
	Esposo("Esposa"),
	Esposa("Esposo"),
	Filho("Filho"),
	Outro("Outro");
	
	private String descricao;
}
