package com.tcc.websocial.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.tcc.websocial.model.Servico;
import com.tcc.websocial.repository.filters.ServicoFilter;

public interface ServicoService extends GenericService<Servico, Long> {

    List<Servico> buscarNome(String nome);
    Page<Servico> listaComPaginacao(ServicoFilter servicoFilter, Pageable pageable);
}