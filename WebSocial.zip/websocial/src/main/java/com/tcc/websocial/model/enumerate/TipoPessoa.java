package com.tcc.websocial.model.enumerate;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum TipoPessoa {
	
	PessoaFisica("Fisica"),
	PessoaJuridica("Juridica");
	
	private String descricao;

}
