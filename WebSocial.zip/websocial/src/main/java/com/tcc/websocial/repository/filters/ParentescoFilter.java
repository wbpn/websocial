package com.tcc.websocial.repository.filters;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ParentescoFilter {

    private String nome;
    private String sobrenome;
    private String apelido;
}