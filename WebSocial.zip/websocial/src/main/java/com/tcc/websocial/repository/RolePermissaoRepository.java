package com.tcc.websocial.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.tcc.websocial.model.RolePermissao;
import com.tcc.websocial.model.RolePermissaoId;
import com.tcc.websocial.repository.query.RolePermissaoQuary;

@Repository
public interface RolePermissaoRepository extends JpaRepository<RolePermissao, RolePermissaoId>, RolePermissaoQuary {

    
}