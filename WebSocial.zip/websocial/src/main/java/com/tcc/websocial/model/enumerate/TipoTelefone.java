package com.tcc.websocial.model.enumerate;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum TipoTelefone {

	TelefoneFixo("Fixo"),
	TelefoneCelular("Celular");
	
	private String descricao;
}
