package com.tcc.websocial.service.exceptions;

public class EmailCadastradoException extends NegocioException {

    private static final long serialVersionUID = 0;

    public EmailCadastradoException(String message) {
        super(message);
    }
}