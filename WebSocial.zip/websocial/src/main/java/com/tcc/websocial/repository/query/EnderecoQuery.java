package com.tcc.websocial.repository.query;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.tcc.websocial.model.Endereco;
import com.tcc.websocial.repository.filters.EnderecoFilter;

public interface EnderecoQuery {

	Page<Endereco> listaComPaginacao(EnderecoFilter contatoFilter, Pageable pageable);
    
}